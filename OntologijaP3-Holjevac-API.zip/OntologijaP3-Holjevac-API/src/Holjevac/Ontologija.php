<?php
namespace Holjevac;

/**
 * @Entity @Table(name="ontologija")
 **/
class Ontologija
{
    /** @Id @Column(type="integer") @GeneratedValue  **/
    private $sifra;

    /** @Column(type="string") **/
    private $drzava;

    /** @Column(type="string") **/
	private $glumac;
	
	/** @Column(type="string") **/
	private $grad;
	
	/** @Column(type="string") **/
	private $izvodac;

	/** @Column(type="string") **/
	private $kontinent;

	/** @Column(type="string") **/
	private $koreograf;
	
	/** @Column(type="string") **/
	private $kostimograf;
	
	/** @Column(type="string") **/
	private $nazivKazalista;
	
	public function getSifra(){
		return $this->sifra;
	}

	public function setSifra($sifra){
		$this->sifra = $sifra;
	}

	public function getDrzava(){
		return $this->drzava;
	}

	public function setDrzava($drzava){
		$this->drzava = $drzava;
	}

	public function getGlumac(){
		return $this->glumac;
	}

	public function setGlumac($glumac){
		$this->glumac = $glumac;
	}

	public function getGrad(){
		return $this->grad;
	}

	public function setGrad($grad){
		$this->grad = $grad;
	}

	public function getIzvodac(){
		return $this->izvodac;
	}

	public function setIzvodac($izvodac){
		$this->izvodac = $izvodac;
	}

	public function getKontinent(){
		return $this->kontinent;
	}

	public function setKontinent($kontinent){
		$this->kontinent = $kontinent;
	}

	public function getKoreograf(){
		return $this->koreograf;
	}

	public function setKoreograf($koreograf){
		$this->koreograf = $koreograf;
	}

	public function getKostimograf(){
		return $this->kostimograf;
	}

	public function setKostimograf($kostimograf){
		$this->kostimograf = $kostimograf;
	}

	public function getNazivKazalista(){
		return $this->nazivKazalista;
	}

	public function setNazivKazalista($nazivKazalista){
		$this->nazivKazalista = $nazivKazalista;
	}

	public function setPodaci($podaci)
    {
      foreach($podaci as $kljuc => $vrijednost){
        $this->{$kljuc} = $vrijednost;
      }
    }

}

?>