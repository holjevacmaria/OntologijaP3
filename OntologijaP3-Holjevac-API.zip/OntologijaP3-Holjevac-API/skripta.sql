create database mholjevac_20_20 default character set utf8mb4;
use mholjevac_20_20;
create table ontologija(
    sifra int not null primary key auto_increment,
    drzava varchar(255) not null,
    glumac varchar(255),
    grad varchar(255),
    izvodac varchar(255),
    kontinent varchar(255),
    koreograf varchar(255),
    kostimograf varchar(255),
    nazivKazalista varchar(255)
);
insert into ontologija(drzava,glumac,grad,izvodac,kontinent,koreograf,kostimograf,nazivKazalista)
values ('Hrvatska','Ivan Horvat','Osijek','Ivan Horvat','Europa','Ljiljana','Neven Mihić','HNK u Osijeku');

drop table ontologija;

select * from ontologija 

DELETE FROM ontologija
WHERE sifra = 1;