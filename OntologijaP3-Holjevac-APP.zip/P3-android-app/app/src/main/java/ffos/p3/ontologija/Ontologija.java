package ffos.p3.ontologija;

import java.io.Serializable;

public class Ontologija implements Serializable {

    public Ontologija() {
        this.sifra = sifra;
        this.drzava = drzava;
        this.glumac = glumac;
        this.grad = grad;
        this.izvodac = izvodac;
        this.kontinent = kontinent;
        this.koreograf = koreograf;
        this.kostimograf = kostimograf;
        this.nazivKazalista = nazivKazalista;
    }

    private int sifra;
    private String drzava;
    private String glumac;
    private String grad;
    private String izvodac;
    private String kontinent;
    private String koreograf;
    private String kostimograf;
    private String nazivKazalista;

    public int getSifra() {
        return sifra;
    }

    public void setSifra(int sifra) {
        this.sifra = sifra;
    }

    public String getDrzava() {
        return drzava;
    }

    public void setDrzava(String drzava) {
        this.drzava = drzava;
    }

    public String getGlumac() {
        return glumac;
    }

    public void setGlumac(String glumac) {
        this.glumac = glumac;
    }

    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public String getIzvodac() {
        return izvodac;
    }

    public void setIzvodac(String izvodac) {
        this.izvodac = izvodac;
    }

    public String getKontinent() {
        return kontinent;
    }

    public void setKontinent(String kontinent) {
        this.kontinent = kontinent;
    }

    public String getKoreograf() {
        return koreograf;
    }

    public void setKoreograf(String koreograf) {
        this.koreograf = koreograf;
    }

    public String getKostimograf() {
        return kostimograf;
    }

    public void setKostimograf(String kostimograf) {
        this.kostimograf = kostimograf;
    }

    public String getNazivKazalista() {
        return nazivKazalista;
    }

    public void setNazivKazalista(String nazivKazalista) {
        this.nazivKazalista = nazivKazalista;
    }
}
